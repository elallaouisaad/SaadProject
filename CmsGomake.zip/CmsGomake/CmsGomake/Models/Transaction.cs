﻿using System;
using System.Collections.Generic;

namespace CmsGomake.Models
{
    public class Transaction
    {
        public int id { get; set; }
        public DateTime Transactiondate { get; set; }
        public string Transactionsum { get; set; }
        public string Transactiondescription { get; set; }
        public DateTime Creationdate { get; set; }
        public ICollection<Client> Clients { get; set; }
    }
}
