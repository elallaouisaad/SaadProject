﻿using System;
using System.Collections.Generic;

namespace CmsGomake.Models
{
    public class Client
    {
        public int Id { get; set; }
        public string Fullname { get; set; }
        public string Phone { get; set; }
        public string mail { get; set; }
        public string address { get; set; }
        public DateTime Creationdate { get; set; }
        public DateTime Updatedate { get; set; }
        public ICollection<Transaction> Transactions { get; set; }
    }
}
