﻿namespace CmsGomake.Models
{
    public class Role
    {
        public int Id { get; set; }
        public string Fullname { get; set; }
    }
}
