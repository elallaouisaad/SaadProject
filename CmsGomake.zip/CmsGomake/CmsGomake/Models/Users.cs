﻿namespace CmsGomake.Models
{
    public class Users
    {
        public int id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
