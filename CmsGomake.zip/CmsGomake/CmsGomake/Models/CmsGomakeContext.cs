﻿using Microsoft.EntityFrameworkCore;
using CmsGomake.Models;

namespace CmsGomake.Models
{
    public class CmsGomakeContext : DbContext
    {
public CmsGomakeContext(DbContextOptions<CmsGomakeContext> options)
            : base(options)
        {

        }
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<Client> Clients { get; set; }
        public object Role { get; internal set; }
        public DbSet<Users> Users { get; set; }
    }
}
